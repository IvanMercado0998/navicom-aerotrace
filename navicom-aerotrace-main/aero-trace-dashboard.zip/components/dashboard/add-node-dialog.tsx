'use client'

import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { MapPin, AlertCircle, X } from 'lucide-react'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'

interface AddNodeDialogProps {
  isOpen: boolean
  selectedLocation: { lat: number; lng: number } | null
  onClose: () => void
  onSubmit: (nodeName: string, lat: number, lng: number, radiusKm: number) => void
  isMapSelectionMode: boolean
  onToggleMapMode: () => void
}

export function AddNodeDialog({
  isOpen,
  selectedLocation,
  onClose,
  onSubmit,
  isMapSelectionMode,
  onToggleMapMode,
}: AddNodeDialogProps) {
  const [nodeName, setNodeName] = useState('')
  const [radiusKm, setRadiusKm] = useState('5')
  const [error, setError] = useState('')

  if (!isOpen) return null

  const handleSubmit = () => {
    setError('')
    if (!nodeName.trim()) {
      setError('Node name is required')
      return
    }
    if (!selectedLocation) {
      setError('Please select a location on the map')
      return
    }
    const radius = parseFloat(radiusKm) || 5
    onSubmit(nodeName, selectedLocation.lat, selectedLocation.lng, radius)
    setNodeName('')
    setRadiusKm('5')
  }

  return (
    <>
      {/* Full-screen map click area when in map selection mode */}
      {isMapSelectionMode && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-40 pointer-events-none"
        />
      )}
      
      {/* Modal Dialog */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        className={`fixed inset-0 ${isMapSelectionMode ? 'bg-transparent pointer-events-none' : 'bg-black/50'} flex items-end justify-center z-50 md:items-center`}
        onClick={isMapSelectionMode ? undefined : onClose}
        pointerEvents={isMapSelectionMode ? 'none' : 'auto'}
      >
        <motion.div
          initial={{ scale: 0.95, opacity: 0, y: 20 }}
          animate={{ scale: 1, opacity: 1, y: 0 }}
          exit={{ scale: 0.95, opacity: 0, y: 20 }}
          onClick={(e) => e.stopPropagation()}
          className={`glass-card rounded-t-2xl md:rounded-2xl p-6 md:p-8 max-w-md w-full md:w-full mx-0 md:mx-4 ${
            isMapSelectionMode ? 'mb-0' : ''
          }`}
          pointerEvents="auto"
        >
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <MapPin className="w-5 h-5 text-blue-400" />
            Add Monitoring Node
          </h2>
          <button
            onClick={onClose}
            className="p-1 hover:bg-white/10 rounded-lg transition-colors"
          >
            <X className="w-4 h-4 text-white/60" />
          </button>
        </div>

        <div className="space-y-4 mb-6">
          {/* Node Name */}
          <div>
            <Label htmlFor="nodeName" className="text-white/80 block mb-2">
              Node Name
            </Label>
            <Input
              id="nodeName"
              value={nodeName}
              onChange={(e) => setNodeName(e.target.value)}
              placeholder="e.g., Pampanga Central Station"
              className="bg-white/10 border-white/20 text-white placeholder:text-white/40"
            />
          </div>

          {/* Location Display */}
          <div>
            <Label className="text-white/80 block mb-2">Location</Label>
            {selectedLocation ? (
              <div className="bg-green-500/20 border border-green-400/40 rounded-lg p-3">
                <p className="text-sm text-green-300">
                  ✓ Location Selected
                </p>
                <p className="text-xs text-green-200 mt-1">
                  Lat: {selectedLocation.lat.toFixed(4)}, Lng: {selectedLocation.lng.toFixed(4)}
                </p>
              </div>
            ) : (
              <div className="bg-yellow-500/20 border border-yellow-400/40 rounded-lg p-3">
                <p className="text-sm text-yellow-300">
                  Click on the map to select location
                </p>
              </div>
            )}
          </div>

          {/* Radius */}
          <div>
            <Label htmlFor="radius" className="text-white/80 block mb-2">
              Monitoring Radius (km)
            </Label>
            <Input
              id="radius"
              type="number"
              value={radiusKm}
              onChange={(e) => setRadiusKm(e.target.value)}
              min="1"
              max="50"
              step="0.5"
              placeholder="5"
              className="bg-white/10 border-white/20 text-white placeholder:text-white/40"
            />
          </div>

          {/* Error Message */}
          {error && (
            <div className="bg-red-500/20 border border-red-400/40 rounded-lg p-3">
              <p className="text-sm text-red-300 flex items-center gap-2">
                <AlertCircle className="w-4 h-4" />
                {error}
              </p>
            </div>
          )}
        </div>

        {/* Map Selection Mode Toggle */}
        <button
          onClick={onToggleMapMode}
          className={`w-full mb-4 py-2 px-4 rounded-lg font-medium transition-colors ${
            isMapSelectionMode
              ? 'bg-blue-500/30 text-blue-300 border border-blue-400/60'
              : 'bg-white/10 text-white/60 border border-white/20 hover:bg-white/20'
          }`}
        >
          {isMapSelectionMode ? '🗺️ Map Mode: ON - Click map to select' : '🗺️ Enable Map Selection'}
        </button>

        {/* Action Buttons */}
        <div className="flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 py-2 px-4 rounded-lg bg-white/10 text-white border border-white/20 hover:bg-white/20 transition-colors font-medium"
          >
            Cancel
          </button>
          <button
            onClick={handleSubmit}
            disabled={!selectedLocation || !nodeName.trim()}
            className="flex-1 py-2 px-4 rounded-lg bg-blue-500/30 text-blue-300 border border-blue-400/40 hover:bg-blue-500/40 disabled:opacity-50 disabled:cursor-not-allowed transition-colors font-medium"
          >
            Create Node
          </button>
        </div>
        </motion.div>
      </motion.div>
    </>
  )
}
