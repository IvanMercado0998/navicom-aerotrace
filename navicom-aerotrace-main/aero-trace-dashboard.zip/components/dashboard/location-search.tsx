'use client'

import React, { useState } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Search, MapPin, X } from 'lucide-react'

interface Location {
  name: string
  lat: number
  lng: number
  type: string
}

interface LocationSearchProps {
  onSearch: (lat: number, lng: number) => void
  onClose: () => void
}

const SAMPLE_LOCATIONS: Location[] = [
  { name: 'San Fernando, Pampanga', lat: 15.0411, lng: 120.6825, type: 'city' },
  { name: 'Angeles City', lat: 15.1274, lng: 120.6208, type: 'city' },
  { name: 'Mabalacat City', lat: 15.2203, lng: 120.5933, type: 'city' },
  { name: 'Floridablanca, Pampanga', lat: 15.1956, lng: 120.8022, type: 'town' },
  { name: 'Guagua, Pampanga', lat: 14.9733, lng: 120.7328, type: 'town' },
  { name: 'Pinatubo Volcano', lat: 15.1321, lng: 120.3506, type: 'volcano' },
  { name: 'Sapang Bato Quarry', lat: 15.1893, lng: 120.7111, type: 'quarry' },
  { name: 'Hagonoy Industrial Zone', lat: 14.8756, lng: 120.9222, type: 'industrial' },
]

export function LocationSearch({ onSearch, onClose }: LocationSearchProps) {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState<Location[]>([])
  const [isOpen, setIsOpen] = useState(true)

  const handleSearch = (value: string) => {
    setQuery(value)
    if (value.length > 0) {
      const filtered = SAMPLE_LOCATIONS.filter(loc =>
        loc.name.toLowerCase().includes(value.toLowerCase())
      )
      setResults(filtered)
    } else {
      setResults([])
    }
  }

  const handleSelect = (location: Location) => {
    onSearch(location.lat, location.lng)
    setQuery('')
    setResults([])
  }

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'volcano':
        return 'bg-red-500/20 text-red-300'
      case 'quarry':
        return 'bg-orange-500/20 text-orange-300'
      case 'industrial':
        return 'bg-purple-500/20 text-purple-300'
      case 'factory':
        return 'bg-yellow-500/20 text-yellow-300'
      default:
        return 'bg-blue-500/20 text-blue-300'
    }
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
          className="glass-card rounded-2xl p-4 max-w-md mx-auto"
        >
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-white flex items-center gap-2">
              <MapPin className="w-4 h-4 text-cyan-400" />
              Search Location
            </h3>
            <button
              onClick={() => {
                setIsOpen(false)
                onClose()
              }}
              className="p-1 hover:bg-white/10 rounded-lg transition-colors"
            >
              <X className="w-4 h-4 text-white/60" />
            </button>
          </div>

          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="w-4 h-4 text-white/40" />
            </div>
            <input
              type="text"
              placeholder="Search by location name..."
              value={query}
              onChange={(e) => handleSearch(e.target.value)}
              className="w-full bg-white/10 border border-white/20 text-white placeholder:text-white/40 pl-10 pr-4 py-2 rounded-lg focus:outline-none focus:border-blue-400/50 focus:bg-white/20 transition-colors"
            />
          </div>

          <AnimatePresence>
            {results.length > 0 && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="mt-3 space-y-2 max-h-64 overflow-y-auto"
              >
                {results.map((location, idx) => (
                  <motion.button
                    key={idx}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    onClick={() => handleSelect(location)}
                    className="w-full text-left bg-white/5 hover:bg-white/10 border border-white/10 rounded-lg p-3 transition-colors group"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className="text-sm font-medium text-white group-hover:text-cyan-300 transition-colors">
                          {location.name}
                        </p>
                        <p className="text-xs text-white/50">
                          {location.lat.toFixed(4)}, {location.lng.toFixed(4)}
                        </p>
                      </div>
                      <span className={`text-xs px-2 py-1 rounded-full whitespace-nowrap ml-2 ${getTypeColor(location.type)}`}>
                        {location.type}
                      </span>
                    </div>
                  </motion.button>
                ))}
              </motion.div>
            )}
          </AnimatePresence>

          {query && results.length === 0 && (
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="text-xs text-white/50 mt-3"
            >
              No locations found
            </motion.p>
          )}
        </motion.div>
      )}
    </AnimatePresence>
  )
}
