'use client'

import React, { useEffect, useRef, useState, useCallback } from 'react'
import maplibregl from 'maplibre-gl'
import 'maplibre-gl/dist/maplibre-gl.css'

interface MonitoringNode {
  id: string
  name: string
  latitude: string
  longitude: string
  isActive: boolean
  mode: string
}

interface PollutionSource {
  id: string
  name: string
  sourceType: string
  latitude: string
  longitude: string
}

interface NodeReading {
  airQualityIndex?: string
  overallRating?: string
}

interface MapProps {
  nodes: MonitoringNode[]
  sources: PollutionSource[]
  selectedNodeId?: string
  onNodeSelect?: (nodeId: string) => void
  readings: Record<string, NodeReading>
  center?: { lat: number; lng: number }
  onMapClick?: (lat: number, lng: number) => void
  isClickMode?: boolean
  nodePerimeters?: Record<string, number>
}

const sourceTypeColors: Record<string, string> = {
  cement_plant: '#E74C3C',
  quarry: '#E67E22',
  volcano: '#C0392B',
  factory: '#8E44AD',
  power_plant: '#E91E63',
  industrial: '#D35400',
  default: '#95A5A6',
}

const ratingColors: Record<string, string> = {
  good: '#27AE60',
  moderate: '#F39C12',
  unhealthy: '#E67E22',
  hazardous: '#E74C3C',
  unknown: '#3498DB',
}

export function PollutionMap({
  nodes,
  sources,
  selectedNodeId,
  onNodeSelect,
  readings,
  center,
  onMapClick,
  isClickMode,
  nodePerimeters,
}: MapProps) {
  const mapContainer = useRef<HTMLDivElement>(null)
  const map = useRef<maplibregl.Map | null>(null)
  // Default to Pampanga, Central Luzon
  const [lng, setLng] = useState(center?.lng || 120.6218)
  const [lat, setLat] = useState(center?.lat || 15.0896)
  const [zoom, setZoom] = useState(10)

  // Handle map clicks for node placement
  const handleMapClicked = useCallback(
    (e: maplibregl.MapMouseEvent) => {
      if (onMapClick && isClickMode) {
        onMapClick(e.lngLat.lat, e.lngLat.lng)
      }
    },
    [onMapClick, isClickMode]
  )

  useEffect(() => {
    if (!mapContainer.current) return

    map.current = new maplibregl.Map({
      container: mapContainer.current,
      style: 'https://basemaps.cartocdn.com/gl/positron-gl-style/style.json',
      center: [lng, lat],
      zoom: zoom,
    })

    map.current.on('move', () => {
      if (!map.current) return
      setLng(Math.round(map.current.getCenter().lng * 100) / 100)
      setLat(Math.round(map.current.getCenter().lat * 100) / 100)
      setZoom(Math.round(map.current.getZoom() * 100) / 100)
    })

    return () => {
      if (map.current) {
        map.current.off('click', handleMapClicked)
        map.current.remove()
      }
    }
  }, [])

  // Handle click mode changes - attach/detach click handler
  useEffect(() => {
    if (!map.current) return

    if (isClickMode) {
      if (mapContainer.current) {
        mapContainer.current.style.cursor = 'crosshair'
      }
      map.current.on('click', handleMapClicked)
    } else {
      if (mapContainer.current) {
        mapContainer.current.style.cursor = 'grab'
      }
      map.current.off('click', handleMapClicked)
    }

    return () => {
      if (map.current && isClickMode) {
        map.current.off('click', handleMapClicked)
      }
    }
  }, [isClickMode, onMapClick, handleMapClicked])

  // Add monitoring nodes to map
  useEffect(() => {
    if (!map.current || nodes.length === 0) return

    // Remove existing markers
    document.querySelectorAll('.node-marker').forEach(el => el.remove())

    nodes.forEach(node => {
      const lat = parseFloat(node.latitude)
      const lng = parseFloat(node.longitude)
      const reading = readings[node.id]
      const rating = reading?.overallRating || 'unknown'

      // Determine color based on rating
      let markerColor = ratingColors[rating] || ratingColors.unknown

      const isSelected = node.id === selectedNodeId
      const size = isSelected ? 50 : 40

      // Create marker element
      const el = document.createElement('div')
      el.className = 'node-marker'
      el.style.width = `${size}px`
      el.style.height = `${size}px`
      el.style.background = markerColor
      el.style.borderRadius = '50%'
      el.style.border = isSelected ? '4px solid white' : '2px solid white'
      el.style.cursor = 'pointer'
      el.style.boxShadow = isSelected ? '0 0 0 3px rgba(52, 152, 219, 0.5)' : '0 2px 4px rgba(0,0,0,0.1)'
      el.style.display = 'flex'
      el.style.alignItems = 'center'
      el.style.justifyContent = 'center'
      el.style.fontSize = '12px'
      el.style.fontWeight = 'bold'
      el.style.color = 'white'
      el.style.transition = 'all 0.3s ease'

      // Add pulse animation for real-time nodes
      if (node.mode === 'realtime') {
        el.style.animation = 'pulse 2s infinite'
      }

      const popup = new maplibregl.Popup({ offset: 25 }).setHTML(`
        <div class="p-2">
          <h3 class="font-bold text-sm">${node.name}</h3>
          <p class="text-xs text-gray-600">Mode: ${node.mode}</p>
        </div>
      `)

      el.addEventListener('click', () => {
        if (onNodeSelect) onNodeSelect(node.id)
      })

      new maplibregl.Marker({ element: el })
        .setLngLat([lng, lat])
        .setPopup(popup)
        .addTo(map.current!)
    })
  }, [nodes, selectedNodeId, onNodeSelect, readings])

  // Add pollution sources to map with enhanced highlighting
  useEffect(() => {
    if (!map.current || sources.length === 0) return

    // Remove existing source markers
    document.querySelectorAll('.source-marker').forEach(el => el.remove())

    sources.forEach(source => {
      const lat = parseFloat(source.latitude)
      const lng = parseFloat(source.longitude)
      const color = sourceTypeColors[source.sourceType] || sourceTypeColors.default

      const el = document.createElement('div')
      el.className = 'source-marker'
      el.style.width = '32px'
      el.style.height = '32px'
      el.style.background = color
      el.style.borderRadius = '50%'
      el.style.border = '3px solid rgba(255, 255, 255, 0.9)'
      el.style.cursor = 'pointer'
      el.style.boxShadow = `0 0 15px ${color}80, 0 2px 8px rgba(0,0,0,0.3)`
      el.style.opacity = '0.95'
      el.style.display = 'flex'
      el.style.alignItems = 'center'
      el.style.justifyContent = 'center'
      el.style.fontSize = '16px'
      el.style.fontWeight = 'bold'
      el.style.color = 'white'
      
      // Add type icons
      const icons: Record<string, string> = {
        volcano: '🌋',
        quarry: '⛏️',
        factory: '🏭',
        industrial: '🏗️',
        cement_plant: '🏢',
        power_plant: '⚡',
      }
      el.textContent = icons[source.sourceType] || '●'

      const popup = new maplibregl.Popup({ offset: 25 }).setHTML(`
        <div class="p-3 bg-gray-900 text-white rounded-lg">
          <h3 class="font-bold text-sm mb-1">${source.name}</h3>
          <p class="text-xs text-gray-300">
            <span class="inline-block px-2 py-0.5 rounded" style="background-color: ${color}40; border: 1px solid ${color}">
              ${source.sourceType.replace(/_/g, ' ').toUpperCase()}
            </span>
          </p>
          <p class="text-xs text-gray-400 mt-2">
            Pollution Source • High Impact Area
          </p>
        </div>
      `)

      new maplibregl.Marker({ element: el })
        .setLngLat([lng, lat])
        .setPopup(popup)
        .addTo(map.current!)
    })
  }, [sources])

  // Update map center when center prop changes
  useEffect(() => {
    if (!map.current || !center) return
    map.current.flyTo({
      center: [center.lng, center.lat],
      zoom: 12,
      duration: 1000,
    })
  }, [center])

  // Draw perimeters for selected node
  useEffect(() => {
    if (!map.current || !selectedNodeId || !nodePerimeters) return

    const radiusKm = nodePerimeters[selectedNodeId]
    if (!radiusKm) return

    // Find the node
    const node = nodes.find(n => n.id === selectedNodeId)
    if (!node) return

    const lat = parseFloat(node.latitude)
    const lng = parseFloat(node.longitude)

    // Create circle using turf.js logic
    const steps = 64
    const coordinates: [number, number][] = []
    const earthRadiusKm = 6371

    for (let i = 0; i < steps; i++) {
      const angle = (i / steps) * Math.PI * 2
      const lat2 = Math.asin(Math.sin(lat * Math.PI / 180) * Math.cos(radiusKm / earthRadiusKm) +
        Math.cos(lat * Math.PI / 180) * Math.sin(radiusKm / earthRadiusKm) * Math.cos(angle))
      const lng2 = (lng * Math.PI / 180) + Math.atan2(Math.sin(angle) * Math.sin(radiusKm / earthRadiusKm) * Math.cos(lat * Math.PI / 180),
        Math.cos(radiusKm / earthRadiusKm) - Math.sin(lat * Math.PI / 180) * Math.sin(lat2))

      coordinates.push([lng2 * 180 / Math.PI, lat2 * 180 / Math.PI])
    }

    // Close the circle
    coordinates.push(coordinates[0])

    // Draw circle on map
    const canvas = document.createElement('canvas')
    const ctx = canvas.getContext('2d')
    if (!ctx) return

    canvas.width = canvas.height = 200
    ctx.fillStyle = 'rgba(52, 152, 219, 0.2)'
    ctx.strokeStyle = 'rgba(52, 152, 219, 0.8)'
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.arc(100, 100, 100, 0, Math.PI * 2)
    ctx.fill()
    ctx.stroke()

    // Remove old perimeter if exists
    if (map.current.getLayer('perimeter-circle')) {
      map.current.removeLayer('perimeter-circle')
    }
    if (map.current.getSource('perimeter-source')) {
      map.current.removeSource('perimeter-source')
    }

    // Add source and layer for perimeter
    map.current.addSource('perimeter-source', {
      type: 'geojson',
      data: {
        type: 'Feature',
        geometry: {
          type: 'LineString',
          coordinates,
        },
        properties: {},
      },
    })

    map.current.addLayer({
      id: 'perimeter-circle',
      type: 'line',
      source: 'perimeter-source',
      paint: {
        'line-color': '#3498DB',
        'line-width': 2,
        'line-dasharray': [5, 5],
        'line-opacity': 0.8,
      },
    })
  }, [selectedNodeId, nodePerimeters, nodes])

  return (
    <div
      ref={mapContainer}
      className="w-full h-full rounded-2xl"
      style={{ minHeight: '600px' }}
    >
      <style>{`
        @keyframes pulse {
          0%, 100% {
            box-shadow: 0 0 0 0 rgba(231, 76, 60, 0.7);
          }
          50% {
            box-shadow: 0 0 0 10px rgba(231, 76, 60, 0);
          }
        }
      `}</style>
    </div>
  )
}
